package com.sky.basket;

public class BasketConditionNotMetException extends RuntimeException {
}
